# Phase 1 Fixes — P0 Safety (scanner-app-fixed)

Working copy of `~/workspace/scanner-app` (original untouched, including the
original zip). Phase 1 is **P0 safety only**. No signal-engine redesign
(chop traded, deliberate short path, low-vol trigger) — that is Phase 2.
No UI dedup, no verbiage sync beyond P0-adjacent fixes, no SaaS work.

## Scope correction (user, 2026-10-25 evening): MAINNET is the target

The user corrected the original brief: he wants **mainnet** trading, not
devnet. He previously had to hand-edit code to get a simulation, and devnet
perps trading does not really work (only on-chain simulation). Consequences
applied in this same pass (never as a later step):

- Live broadcast is **not disabled**. It is **correct and intentional**:
  `wantsLive` means `paper:false, simulate:false` and a real broadcast;
  `wantsLive=false` means paper or simulate and never a broadcast.
  Recorded order status reflects what actually happened in every case.
- Mode is **env configuration, not code edits and not UI switches**.
  One unified resolution (`resolveTradingMode`, canonical in
  `public/jupiter.js`, imported by `bot-service.cjs`) drives both halves.
- Devnet is **not presented as a live-trading test path**: the Jupiter
  perps program ID and custody addresses in this code are mainnet
  addresses, so devnet + live flags force effective mode to SIMULATE.
  Honest rollout: paper → simulate → tiny live on mainnet (verify on
  Solscan) → scale.
- Because live WILL be real after this fix, the safety items (auth, mode
  gates, wallet unification, real guardrails, no auto-generated wallets,
  no fake data) are MORE critical, and they landed in the SAME pass as
  the flag fix. There is no delivered state where live can be armed
  without auth.

## Unified mode resolution (the env vars that control mode)

Canonical implementation: `resolveTradingMode()` in `public/jupiter.js`
(exported as `resolveTradingMode` + `TRADING_MODE`). `bot-service.cjs`
imports that exact object; a local fallback with identical logic runs
ONLY if the Jupiter module fails to load, and warns loudly.

| Variable | Values | Default |
|---|---|---|
| `SOLANA_NETWORK` | `mainnet-beta` \| `devnet` | `mainnet-beta` |
| `PAPER_TRADING` | `true` \| `false` | `true` (paper) |
| `SIMULATE_TX` | `true` \| `false` | see ladder |
| `SOLANA_RPC` / `HELIUS_RPC_URL` | RPC URL override | network default |
| `BOT_AUTH_TOKEN` | bearer token for mutating routes | **required in production** |
| `WALLET_ENCRYPTION_KEY` | wallet-file encryption key | **required for wallet crypto** |
| `DASHBOARD_ORIGIN` | single allowed CORS origin | unset = same-origin only |

Legacy aliases honored only when the canonical var is unset:
`DEVNET=true` ⇒ devnet; `PAPER_TRADE` ⇒ `PAPER_TRADING`;
`DRY_RUN` ⇒ `SIMULATE_TX`. Env is read once at module load — **changing
mode requires a process restart**. Runtime network/RPC switches via
`/mode` and `/wallet-config` are rejected (400) with a message naming the
env var, because `jupiter.js` fixes its connection at load and a
state-only switch used to silently disagree with the signer.

Fail-closed ladder (each step toward live requires explicitly opting OUT
of the safer mode):

- `PAPER_TRADING=false` + `SIMULATE_TX=false` → **live**
- `PAPER_TRADING=false` + `SIMULATE_TX=true` (or unset) → **simulate**
- `PAPER_TRADING=true` (or unset) → **paper**

Devnet rule: `SOLANA_NETWORK=devnet` + live flags → `configuredMode`
stays `live` but `effectiveMode` is forced to `simulate`
(`devnetForcedSimulate: true`) with a loud warning at startup.

### What each mode does

**Paper.** Orders are local virtual records in the paper store, matched
by the local keeper against the price feed. Nothing touches the chain:
no broadcast, no RPC simulation, no wallet needed. Order records say
`AUTOTRADE_BOT`. This is the default when nothing is set, and the only
mode that works with zero configuration.

**Simulate.** Orders build the real Jupiter Anchor transaction and run
it through on-chain RPC simulation (`simulateTransaction`), but are
never broadcast, so no funds ever move. Order records say `SIMULATED`
and the keeper status reports the simulation outcome (`Simulated OK (not
broadcast)` or `SIMULATION_FAILED: …`). A wallet public key is needed as
the transaction's fee-payer identity for simulation, but no signing key
is required to simulate. This is the last step before any real money.

**Live.** Orders are really broadcast to the Jupiter perps program on
`SOLANA_NETWORK` (use `mainnet-beta`; devnet cannot broadcast, see
above). Order records say `LIVE_ONCHAIN` only after the interlock passes
and the broadcast is submitted; failures are recorded as
`JUPITER_BROADCAST_FAILED: …`, never hidden. Live additionally requires,
in the same process: `BOT_AUTH_TOKEN` set, a configured wallet keypair,
≥ 0.02 SOL gas, the real guardrail policy passing, and the safety toggle
armed via `/safety-toggle` (or `/mode` live) after the audit passes.
A live-configured but unarmed process REJECTS signals with
`SAFETY_INTERLOCK_ENGAGED` — it never silently papers them. A per-request
`simulate` flag can never escalate beyond the env mode, and arming is
impossible from a paper/simulate process (the env gate rejects it).

### How to verify which mode a running process is in

1. **Startup log.** Both halves print the same line on start (look for
   `TRADING MODE`):
   `🚦 [TRADING MODE] network=mainnet-beta | mode=PAPER | broadcast=NO | wallet=none | env: PAPER_TRADING=true SIMULATE_TX=true SOLANA_NETWORK=mainnet-beta`
   (Live shows `mode=LIVE | broadcast=LOCKED/ARMED`.) No secrets are ever
   logged — only the mode, network, and wallet public key if configured.
2. **GET /state → `tradingMode`.** Returns `{ network, rpcUrl,
   configuredMode, effectiveMode, devnetForcedSimulate, armed }`.
3. **UI.** The React header shows a `TRADING MODE:` badge (network ·
   mode · ARMED/LOCKED) refreshed from `/state` every 30s, falling back to
   "mode unknown (bot unreachable)" — never a hardcoded network claim.
   The standalone dashboard's order toasts use the mode from the
   `/signal` response (`tradingMode` + `network` fields).
4. **Order records.** `executionMode` is `AUTOTRADE_BOT` (paper),
   `SIMULATED`, or `LIVE_ONCHAIN` (live only). If it says `LIVE_ONCHAIN`,
   a broadcast was submitted; anything else never touched the chain.

## P0 items — files, changes, what was NOT changed, verification

### 1. Inverted simulate/paper flags (with 3 + 4, same pass)
- `bot-service.cjs` (`placeSignalOrder`): the old call passed
  `paper: !wantsLive, simulate: wantsLive`, so a live-armed order only
  SIMULATED while being recorded as `LIVE_ONCHAIN`. Now the call is
  chosen by env mode: paper → `{paper:true, simulate:false}`; simulate →
  `{paper:false, simulate:true}`; live → `{paper:false, simulate:false}`.
  `keeperStatus` now tracks the real Jupiter outcome (broadcast
  submitted / simulated OK / `*_FAILED`) instead of unconditionally
  claiming on-chain submission. The synchronous `placed` response means
  "accepted", not "broadcast confirmed".
- `public/jupiter.js` (`resolveExecutionMode`): env fallback now uses the
  unified effective mode. `placeLimitOrder` itself unchanged in structure.
- NOT changed: the keeper's fill/TP/SL logic, sizing, slippage limits.
- Verified: mode-ladder tests (paper/simulate/live-unarmed/devnet, 19/19);
  paper smoke 13/13; jupiter gate tests 5/5.

### 2. Server-side direction validation + regime-name mismatch
- `bot-service.cjs` (`placeSignalOrder`): allowlist at the top, before
  evaluation: green/buy/long ONLY; anything else returns
  `DIRECTION_NOT_ALLOWED`. This closes the hole where a red signal from
  `dashboard.html` was mapped to a Short order. Comment marks the seam:
  `PHASE 2 SEAM: a deliberate, designed short path plugs in here` — the
  short path is NOT built in this phase.
- `server_strategy_auto_switcher.cjs`: the −10x branch now accepts BOTH
  `FLASH_CRASH` and `FLASH_CRASH_VOLATILITY` (UI/backtest emit the
  former; the branch only recognized the latter, so flash-crash signals
  missed the reduction and, with default `GRADE_A`, got the +10x boost).
- `dashboard.html` (`sendSignalToBot`): defense-in-depth green-only gate
  (server allowlist is authoritative).
- NOT changed: the signal engine, hooks, tiers, or the long-only sizing.
- Verified: red/yellow `/signal` → rejected in smoke tests; switcher
  syntax-checked; no short path exists in the fixed copy.

### 3. Mode gates on close/cancel/trigger
- `public/jupiter.js`: shared `resolveExecutionMode(opts)` helper;
  `placeLimitOrder` uses it; `placeTriggerRequest` gained an `opts`
  parameter and honors the caller's `paper` flag (old code checked only
  env `IS_PAPER_TRADING`, so a live open could get virtual paper
  triggers); `cancelOrder`/`closePosition` gained `opts` + a mode gate.
  **Absent opts are treated as paper (fail closed)** for close/cancel/
  trigger — stricter than `placeLimitOrder`'s env fallback. Only an
  explicit live request (from a `LIVE_ONCHAIN` order record) broadcasts.
- `bot-service.cjs` (`closeOrder`/`cancelOrder`): pass the order's own
  mode explicitly (`paper: executionMode !== 'LIVE_ONCHAIN'`).
- NOT changed: `public/jupiter.cjs` (unused byte-duplicate; no require
  references — delete or re-sync in Phase 2 if ever wired in).
- Verified: jupiter gate tests 5/5 (paper order, no-opts refusals without
  throw, explicit-paper refusal); `placeTriggerRequest` is not exported,
  so its gate is verified by reading + structural identity with the
  tested gates.

### 4. Auth, CORS, sensitive files
- `bot-service.cjs` (`handleApiRequest`): bearer-token auth
  (`BOT_AUTH_TOKEN` from env only, timing-safe compare) on every
  mutating route (POST/DELETE to `/signal`, `/close`, `/cancel`,
  `/wallet-config`, `/safety-toggle`, `/mode`, `/halt`, `/resume`,
  `/portfolio-balance`, `/balance`, `/api/trades`, `/trades`,
  `/signal-status`, `/api/bot/signal-status`, `/update-price`,
  `/simulate-keeper-fill`, `/airdrop`, `/reset-circuit-breaker`,
  `/autotrade/toggle`, `/api/bot/autotrade/toggle`). 401 on mismatch;
  503 fail-closed when `NODE_ENV=production` and no token; one-time loud
  warning in dev without a token. CORS `*` replaced with
  `DASHBOARD_ORIGIN` (header omitted when unset = same-origin only).
  `getBody` gained a 1 MB cap (413) and an error handler (400).
  **Bug found by testing, fixed:** the auth block originally ran before
  `sendJson` was defined, turning every 401 into a 500 (TDZ
  ReferenceError). It now runs after `sendJson`/`getBody` are defined.
- `server.cjs` + `vite.config.ts`: middleware 404s `paper-positions.json`
  and `wallet*.json` before static serving (dev and prod).
- NOT changed: read-only GET routes (still unauthenticated — `/state`
  exposes mode/balance but no secrets).
- Verified: smoke 13/13 (401s, 404s); fail-closed 6/6 (production 503,
  read-only health still 200).

### 5. Key storage
- `bot-service.cjs`: hardcoded `DEFAULT_ENCRYPTION_SECRET` deleted;
  `requireEncryptionKey()` throws unless `WALLET_ENCRYPTION_KEY` is set;
  new encryptions use AES-256-GCM (12-byte IV, authTag); legacy CBC is
  read-only and still requires the env key; plain 64-byte arrays are
  labeled `PLAINTEXT`, never as an encryption scheme. No existing user
  files were re-encrypted (none exist in this copy).
- `public/jupiter.js` `decryptWalletPayload` (PBKDF2 + CBC) already fails
  closed without an env passphrase, so it was left as the legacy read
  path.
- Verified: wallet-generate without the key → 400 + no file created;
  grep confirms no hardcoded secret remains.

### 6. Wallet unification + no auto-generation
- `bot-service.cjs` (`loadActiveKeypair`): env key first
  (`MAINNET_PRIVATE_KEY` / `SOLANA_PRIVATE_KEY`, mirroring
  `jupiter.js getKeypair()`), then `KEYPAIR_PATH`, then network-aware
  root wallet files; `public/` candidates REMOVED (web-served directory);
  **no auto-generation** — unconfigured returns null with "No signing
  key configured"; generation only via explicit `/wallet-config` action.
  `generateTestingKeypair`/`saveImportedKeypair` now use GCM and report
  `AES-256-GCM`.
- NOT changed: `jupiter.js getKeypair()` still loads a mainnet key
  unconditionally even for paper trades (P1, not Phase 1); in paper mode
  the paper branches at its key load make paper orders work keyless
  (proven by smoke tests with wallet: none).
- Verified: no `wallet*.json` exists in the fixed copy after all tests;
  `/state` wallet shows `isConfigured: false` with a clear error.

### 7. /close requires a target
- `bot-service.cjs`: `/close` without `requestPDA`/`positionPDA` and
  without explicit `closeAll: true` → 400 (old code flattened EVERYTHING
  on a missing PDA). `closeAll: true` remains as the deliberate,
  auth-gated kill-switch. `AutoTradeJupiterView` panic button now sends
  `closeAll: true`.
- `dashboard.html`: `botClosePosition` now sends `requestPDA` (button
  passes `p.requestPDA`); `checkFisherAutoClose` disabled (no-op with
  comment) until close semantics are re-verified end to end.
- Verified: smoke tests (400 without PDA, 200 with `closeAll: true`).

### 8. Real risk-guardrail checks
- `server_strategy_auto_switcher.cjs`: new `getRiskGuardrailPolicy()`
  computing the TRUE reachable bounds from the tier table (max reachable
  leverage = max tier base + 10 boost, clamped at the 60 manual-offset
  clamp; SL coeffs 1.2/1.5/1.5; tier margins $25/$50/$100 vs the $500 code
  clamp; risk caps 3%/5%/10%). `bot-service.cjs`
  (`auditWalletAndSafety`) uses it instead of hardcoded `passed: true`
  and reports the true numbers (the old "40x / 1.5x ATR / $30 margin"
  copy was false).
- NOT changed: tier values themselves, the +10x boost, or the 60 clamp
  (P1 redesign, not Phase 1).
- Verified: guardrail condition present in the audit path; smoke servers
  start with the audit available (safety-toggle enable reaches the env
  gate first in paper mode, as designed).

### 9. Fake data
- `bot-service.cjs`: all ticker `119.05` fallbacks → errors
  (`All price sources failed`); all klines `generateSyntheticKlines`
  fallbacks → errors; `generateSyntheticKlines` deleted (backtests use
  `src/engine/generator.ts`, explicitly synthetic, never on live paths);
  `auditWalletAndSafety` balance sync skips when `marketPrice` is not a
  valid number > 0 (no `|| 119.05`); trades POST requires explicit prices
  (else 400); `generateTradesCsv` fallbacks → empty cells.
- `LiveDashboardView.tsx`: `setIsLiveSynced(false)` on feed failure, so
  the dispatcher stops during an outage (it previously stayed synced
  forever after the first calculation).
- `dashboard.html`: synthetic klines are explicitly flagged
  (`lastSignalFeedSynthetic`, toast on transition); `sendSignalToBot`
  refuses to dispatch while the signal feed is synthetic.
- NOT changed: chart rendering of synthetic candles (flagged, not hidden);
  the backtest engine's synthetic generator (its purpose).
- Verified by reading + smoke (servers start; no fabricated prices in
  code paths — one remaining `119.05` is a comment).

### 10. Route parity
- `server.cjs`: `/signal-status` routed to `bot-service` (was 404 on
  Render); `/dashboard` → `/dashboard.html` redirect; sensitive-file
  block (see item 4); `startAutonomousKeeperDaemon` now exported from
  `bot-service.cjs`, so the "AUTOTRADE DAEMON active" log is true
  instead of a no-op call.
- `vite.config.ts`: same sensitive-file 404 block in dev middleware.
- Verified: smoke (`/signal-status` 200 with auth, 401 without;
  `/dashboard` 302).

### Integrity extras (shipped with P0)
- `public/paper-positions.json`: replaced with an empty ledger
  (`{"balance":30.0,"dailyPnL":0.0,"orders":{},"trades":[]}`); seeded
  `ord_init_001` block, persisted-trade margin rewrite, and the second
  copy in `getDeduplicatedTradesList` all removed.
- `DashboardCalculator.tsx`: fabricated "Backtest" tab (hardcoded 12/15
  wins) replaced with an honest empty state; Oct-3 seeded trades removed;
  row-mapping fallbacks (119.46/118.95/600.00/−0.30/−2.86/29.65) → 0/empty.
- `.env.example`: rewritten for the unified scheme (safe Stage-1 paper
  defaults + full ladder + devnet honesty + rollout). Documentation
  only — dotenv loads `.env`, not `.env.example`.
- `src/components/Header.tsx`: hardcoded "Jupiter Devnet Auto-Trader"
  subtitle replaced with the resolved-mode badge (see above).

## Deliberately NOT changed in Phase 1

Signal engine (hooks, ADX sit-outs, 5m confirmation, tiers, sizing);
deliberate short path (seam marked, not built); chop-traded redesign;
tier-table unification; backtest/live trigger unification; UI dedup
beyond the P0-adjacent fixes; verbiage sync beyond mode labels; SaaS/
multi-user work; P1 bugs (circuit-breaker latch, +10x boost removal,
short-side keeper, banked-PnL on close, priority-fee reduction,
`getOrderStatus` missing-account handling, trigger-fallback fix,
`parseKeypairFromInput` truncation, `postMessage` origin checks, dead
`assembleJupiterOrderTx`/`startPort3001Server` cleanup, rate limiting
beyond the 1 MB body cap, README rewrite, `render.yaml`); the
`public/jupiter.cjs` duplicate; `jupiter.js getKeypair()` unconditional
mainnet-key load (P1).

## Verification results (all in ~/workspace/scanner-app-fixed only)

- `node --check`: bot-service.cjs, server.cjs,
  server_strategy_auto_switcher.cjs, public/jupiter.js — all pass.
- `npm install` (inside fixed copy only): 334 packages, success.
- `npm run lint` (`tsc --noEmit`): pass, exit 0.
- `npm run build` (`vite build`): pass (~9s; one chunk-size warning only).
- Paper smoke (server.cjs, PAPER+SIMULATE env): **13/13** — auth 401s,
  red/yellow rejected, green placed as paper, close 400/`closeAll` 200,
  sensitive files 404, dashboard 302, signal-status 200/401.
- Mode ladder (4 servers, fresh env each): **19/19** — simulate
  effective mode + placed-as-simulate + no LIVE_ONCHAIN; live-unarmed
  rejected (not papered, not broadcast); devnet forced to simulate;
  paper env gates (safety-toggle, /mode live, runtime network switches);
  `simulate:false` payload cannot escalate in paper mode.
- Jupiter gates (in-process, paper only): **5/5** — paper order,
  no-opts close/cancel refusals without throw, explicit-paper refusal.
- Fail-closed: **6/6** — wallet-generate without key → 400 + no file;
  production without token → 503, read-only health still 200.
- Ledger restored to empty after every test run; no `wallet*.json` in
  the fixed copy; original `~/workspace/scanner-app` untouched
  (verified: still contains the seeded ledger + old fallbacks).
- NOT runtime-tested: a real live broadcast (would move real funds —
  must be the user's tiny-live step, verified on Solscan); RPC
  simulation against a live RPC (simulate tests passed through the
  local path; if the RPC is unreachable at runtime, simulation fails
  closed with `SIMULATION_FAILED`, never broadcasts).

## What is now gated, and what still is NOT (no live-safety claim)

Gated: every mutating route behind `BOT_AUTH_TOKEN` (production
fail-closed); closes/cancels/triggers behind explicit live mode;
live arming behind env mode + safety-toggle audit + keypair + gas;
wallet crypto behind `WALLET_ENCRYPTION_KEY` (GCM, no fallback secret);
no auto-generated wallets; no silent fake prices; no target-less mass
close; no direction outside the long-only allowlist; no per-request
mode escalation; no runtime network/RPC switches; no persisted-state
override of env mode.

NOT yet gated (known, Phase 2 or operator responsibility): read-only GET
routes are unauthenticated (they expose mode/balance, no secrets);
single-user global state (no tenants — do not multi-tenant this copy);
no rate limiting beyond the 1 MB body cap; the standalone dashboard's
Telegram token still lives in browser localStorage; priority fees remain
0.1 SOL/tx hardcoded (P1); a persisted ARMED toggle carries across
restarts in live env (disarm via `/safety-toggle` or `/mode` simulate);
the safety audit's RPC/guardrail values are audit-time, not re-checked
on every live signal (keypair + gas ARE re-checked per live signal).
**Do not deploy to a public URL without `BOT_AUTH_TOKEN` set and
`NODE_ENV=production`.**

## Open items / human decisions

1. **Tiny-live verification is the user's step.** This phase proves the
   ladder up to live-unarmed rejection; the first real broadcast must be
   tiny, on mainnet-beta, with the safety toggle armed, and verified on
   Solscan before any size.
2. **Persisted arming across restarts (live env).** Kept deliberately
   (an armed toggle survives a restart); if the user wants arming to
   expire on restart, that is a small Phase 2 change.
3. **`public/jupiter.cjs`.** Untouched unused duplicate of the old
   `jupiter.js`. Delete it or re-sync it in Phase 2 if it is ever wired
   in; shipping both invites a stale-code accident.
4. **Delivery layout.** This copy preserves the correct zip layout
   (`public/`, `src/engine/`, root `package.json`). The public repo's
   mangled layout (files at root, `src/engin`) must NOT be used as the
   base for these fixes — Path A delivery is: user pushes this fixed
   copy's layout.
5. **Simulate needs a wallet public key for the fee-payer identity.**
   If simulation fails in the user's environment for key reasons, the
   failure is recorded (`SIMULATION_FAILED`), not broadcast — but the
   exact RPC/keypair combination for simulation should be confirmed
   during the user's simulate-stage run.
