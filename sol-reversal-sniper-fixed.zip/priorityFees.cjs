// priorityFees.cjs — shared priority-fee configuration (Phase 2).
//
// ONE env parsing, used by public/jupiter.js (live transaction
// construction), server_strategy_auto_switcher.cjs (fee-guard estimate),
// and bot-service.cjs (dead-code assembly path), so the parts of the
// system can never disagree about what a transaction costs.
//
// Units (Solana): 1 lamport = 1000 micro-lamports, so
//   priorityFeeLamports = microLamportsPerCU * computeUnitLimit / 1000.
// At the OLD hardcoded default (250,000 micro-lamports x 400,000 CU)
// that is 100,000,000 lamports = 0.1 SOL per transaction — the audit's
// "0.1 SOL/tx" figure was CORRECT (an earlier Phase 2 note claiming a
// 1000x overstatement used the wrong divisor and has been corrected;
// see PHASE2_NOTES.md). The old default was still needlessly high
// (250x the new default), so Phase 2 makes it env-driven, small by
// default, and capped.
//
// Env vars:
//   PRIORITY_FEE_MICRO_LAMPORTS — default 1000, clamped to [0, 50000].
//     At the 400,000 CU default that is 400,000 lamports (0.0004 SOL)
//     per transaction by default, and at most 20,000,000 lamports
//     (0.02 SOL) at the cap.
//   COMPUTE_UNIT_LIMIT — default 400000 (the previously working value;
//     lowering it risks failed transactions if the perps instructions
//     need more compute, so it is NOT reduced by Phase 2).
// A clamped value logs a warning once at module load; the clamp is a
// safety bound, not a silent rewrite (the effective value is returned
// and logged by callers that print mode/config).

let warnedClamp = false;

function getPriorityFeeConfig() {
  const rawMicro = parseInt(process.env.PRIORITY_FEE_MICRO_LAMPORTS || '1000', 10);
  const rawCu = parseInt(process.env.COMPUTE_UNIT_LIMIT || '400000', 10);
  const microLamports = Number.isFinite(rawMicro)
    ? Math.max(0, Math.min(rawMicro, 50000))
    : 1000;
  const clamped = Number.isFinite(rawMicro) && rawMicro > 50000;
  if (clamped && !warnedClamp) {
    warnedClamp = true;
    console.warn(
      `[PRIORITY FEE] PRIORITY_FEE_MICRO_LAMPORTS=${rawMicro} exceeds the 50000 cap; clamped to 50000.`,
    );
  }
  const computeUnits = Number.isFinite(rawCu) && rawCu > 0 ? rawCu : 400000;
  const lamportsPerTx = (microLamports * computeUnits) / 1000;
  return {
    microLamports,
    computeUnits,
    clamped,
    lamportsPerTx,
    solPerTx: lamportsPerTx / 1000000000,
  };
}

module.exports = { getPriorityFeeConfig };
