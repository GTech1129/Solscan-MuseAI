# Phase 2 Notes — signal redesign, UI dedup, verification

Phase 2 builds on Phase 1 (see `PHASE1_FIXES.md`) and does not regress
any Phase 1 gate: bearer auth on mutating routes, mode gates on
close/cancel/trigger, env-driven mode resolution, wallet unification
(no auto-generation), fake-data removal, `/close` requires a target.
No live broadcast was tested. The first real broadcast remains the
user's tiny-live step, verified on Solscan. Never claim live safety
from anything below.

## 1. The canonical trigger (the core job)

**One trigger, used by live AND backtest.** `src/engine/trigger.ts`
(`evaluateTrigger`) is the single implementation. The live dashboard
(`src/components/LiveDashboardView.tsx`) and the backtest
(`src/engine/backtest.ts`) both call it. The three divergent
implementations from the audit are gone:

- React `calcSignalEngine` — removed from `src/engine/indicators.ts`;
  its callers were rewired to `evaluateTrigger`.
- `dashboard.html` `calcSignal` — the page is retired (see §3).
- Backtest inline trigger — replaced by `evaluateTrigger` in
  `src/engine/backtest.ts`.

**Exact conditions (regime → hooks → confirmation → sizing):**

1. **Regime** (`classifyRegime`): FLASH_CRASH if HTF red + price below
   VWMA + ADX > 35. Else MARKET_CHOP if ADX < 20. Else
   BULL_TREND_DRIFT if HTF green + price above VWMA + ADX > 45. Else
   RANGE_BOUND_SUPPORT.
2. **Hooks.** Long: standard (CCI rising + Fisher rising + bullish
   candle) OR slow-bull (Tenkan rising 2 bars + 15m volume ≥ 25k).
   Short (mirror): standard (CCI falling + Fisher falling + bearish
   candle) OR slow-bear (Tenkan falling 2 bars + 15m volume ≥ 25k).
   Conflicting hooks (long hook + short hook both true) yield NONE —
   the trigger never guesses a side.
3. **Confirmation.** 2 consecutive closed 5m bars in the signal's
   direction (doji counts as green, matching the live view). Omitted
   counts are 0, never auto-confirmed. 5m feed failure → state
   UNKNOWN, uiSignal `unknown`, with a visible feed warning — never a
   silent block, never a stale green.
4. **Sizing** (from `src/engine/tiers.ts`, mirrored by the server —
   see §2): tier margin, TP1 0.35 (0.20 in chop), TP2 0.55/0.70/0.85
   (×0.75 in chop; BULL max(1.20, 1.50×ATR)), SL 1.2/1.5/1.5×ATR
   clamped by the tier dollar risk cap, TP split 30/70. Entry offsets:
   momentum → 0.00 post-only best bid; ATR < 0.35 → 0.10×ATR clamped
   0.03–0.05; else 0.25×ATR clamped 0.08–0.20. Shorts mirror longs
   (momentum measured off the candle low).

## 2. Design decisions (with rationale)

### Chop is traded at reduced size — half margin, tighter TP1, faster exits

- Margin ×0.5, TP1 0.20 (from 0.35), TP2 at 75% of tier distance
  (rounded to cents: T1 0.41), stops UNCHANGED (ATR-based).
- Keeper stagnation: chop 2 bars / $0.10 adverse vs standard 3 bars /
  0.30×ATR adverse.
- Rationale: the user explicitly asked for chop to be traded, not sat
  out. Halving margin halves the dollar risk of the noisiest regime
  while keeping the trade recognizable; tightening TP1 matches the
  smaller expected excursion; faster exits cut the time a chop trade
  spends being wrong. Stops stay ATR-based because tightening stops
  in the noisiest regime would just manufacture stop-outs.

### Flash crash sits out BOTH directions (flagged decision for the user)

- FLASH_CRASH (ADX > 35 + HTF red + price below VWMA) = no new
  positions, long or short. The task's recommendation was "no new
  shorts into a liquidation cascade unless a tight, reduced-size
  breakdown setup confirms." Phase 2 chose the stricter rule: no new
  shorts at all during a flash crash.
- Rationale: a flash crash is a liquidation cascade. Longs are
  stopped out by definition, and a new short entered mid-cascade
  risks a violent snap-back plus liquidation on the same move.
  The flagged alternative (tight, reduced-size breakdown short) is
  left for the user to revisit — it would need its own confirmation
  rule and has no test coverage today.

### Fee guard: skip above 0.75, warn above 0.30 of TP1 value (flagged)

- Expected round-trip cost = 2 × exchange fees (0.0005 × notional per
  side, the server's rate) + 2 × priority fees (shared config, SOL ×
  entry price), compared against tokens × tp1Dist. Above 0.75 the
  trade is SKIPPED (`FEE_GUARD_SKIP`); above 0.30 it is placed with a
  loud warning. Default ON, env-tunable (`FEE_GUARD_MAX_FRACTION`,
  `FEE_GUARD_WARN_FRACTION`).
- Why 0.75 and not 0.50: the fee ratio is margin-independent
  (exchange fees scale with notional exactly like TP1 value), so at
  SOL ~$100 the canonical chop trade sits at ~0.51 from exchange fees
  alone (0.001 × entry / 0.20). A 0.50 threshold would veto the entire
  chop regime the user asked to trade. 0.75 still blocks genuinely
  fee-dominated trades (chop at SOL > $150, standard at SOL >
  $262.50 at the server's 0.0005 rate), while the 0.30 warning fires
  honestly on ~$100 chop trades (fees ≈ 50% of TP1 there).
- Open calibration item: the backtest default fee rate is 0.0008 per
  fill, but the server guard uses 0.0005 per side. The two disagree
  by ~37%. At 0.0008, chop at SOL ~$110 has ratio ~0.88 and WOULD be
  skipped. The true Jupiter perps taker fee needs confirming before
  live sizing; see §7.

### Priority fees: env-driven, capped

- New shared module `priorityFees.cjs`: `PRIORITY_FEE_MICRO_LAMPORTS`
  default 1000, clamped to [0, 50000] with a once-only warning;
  `COMPUTE_UNIT_LIMIT` default 400000. Cost in lamports =
  microLamports × CU / 1000 (1 lamport = 1000 micro-lamports).
  New default: 400,000 lamports = 0.0004 SOL/tx (~$0.04 at $100 SOL);
  at the cap: 20,000,000 lamports = 0.02 SOL/tx.
- **Correction of an earlier Phase 2 note (recorded here, NOT by
  editing the historical `AUDIT_REPORT.md`): the audit's "0.1 SOL/tx"
  was CORRECT.** Old default 250,000 × 400,000 / 1000 =
  100,000,000 lamports = **0.1 SOL/tx** (~$10 at $100 SOL). An earlier
  draft of this note claimed a 1000x overstatement; that used the
  wrong divisor (1,000,000 instead of 1,000) and was itself wrong.
  The old default was still needlessly high (250× the new default)
  and is now env-driven with a cap — and at ~$10/tx it genuinely
  would have eaten penny-wide moves, which is why capping it mattered.
  All tx-construction sites in `public/jupiter.js` and
  `bot-service.cjs` use the shared config; the dead 250000/400000
  literals are gone. Note for the fee guard: at the new default the
  priority-fee component (~$0.04/tx) is negligible next to exchange
  fees, so guard outcomes are essentially unchanged by this fix.

### Stop-loss clamp observation (preserved behavior, not a Phase 2 change)

- On small balances the dollar risk cap binds before the ATR
  coefficient: a T1 $30 account's stop at $100 prices is ~10¢
  (maxDollarLoss $0.90 minus ~$0.40 fee estimate, divided by 4.95
  tokens = $0.101), not 1.2×ATR ($0.48). The ATR coefficient is an
  upper bound; the dollar cap binds first. The backtest applies the
  same clamp so live and backtest SL conversion agree. Consequence
  the user should know: live T1 stops are much tighter than the ATR
  coefficient suggests.

### dashboard.html: retired to a redirect (not delegated)

- The 3,151-line standalone app was replaced with a redirect stub
  (meta refresh + `window.location.replace('/')`); `server.cjs`
  `/dashboard` and `vite.config.ts` `/dashboard` now 302 to `/`.
- Rationale: the React SPA is canonical. The old page's `calcSignal`
  diverged (no 5m gate, hardcoded $120 margin, own 2-bar cooldown)
  and its postMessage bridge overwrote the SPA's indicators on every
  message — a second live signal path with different gates.
  Delegating would have left a thin wrapper with no value over a
  redirect.
- What it had, and where it went: live signal tiles + charts → React
  LiveDashboardView (same data, canonical trigger, 5m gate the old
  page lacked); standalone calculator → DashboardCalculator inside the
  SPA (the fabricated "backtest" tab was removed in Phase 1 and is NOT
  restored — the tab is an honest empty state); live-backtest variant
  → canonical backtest + `scripts/verify-trigger.ts`; browser-side
  Telegram alerts → DROPPED (a browser page holding a Telegram bot
  token is a credential leak by construction; server-side Telegram
  delivery is future work); 2-bar cooldown → DROPPED as a live gate
  (never part of the canonical trigger; live uses the dispatcher's
  5-minute debounce; the backtest keeps its own cooldown/circuit-
  breaker simulation).

### One tier table, enforced by test

- `src/engine/tiers.ts` is the source of truth; the CJS server
  switcher mirrors it field-for-field. `tests/tier-parity.test.ts`
  asserts parity on every field (leverage, riskCapPct,
  maxRiskDollarCap, tp1Dist, tp2Dist, tp2AtrMult, slAtrMult,
  defaultMargin, compoundRate, min/maxBalance, names, legacyIds).
  `maxOpenPositions` (1/2/3 by tier) is server execution policy, NOT
  canonical sizing, so it is preserved unchanged and excluded from
  parity. A sub-cent parity gap found by the tests (chop TP2 0.41 vs
  0.4125) was fixed by rounding the server fallback to cents exactly
  like the trigger.
- Leverage UNCHANGED: base 20/35/50, +10x server boost (BULL regime
  or GRADE_A), 60x max reachable. Risk caps 3%/5%/10%. Margins
  $25/$50/$100. All UI copy now matches (the old "40x cap / 1% cap /
  $11 margin" copy is gone).
- Removed as unauthenticated/unused levers: `manualLeverageOffset`
  (no UI sender), backtest manual sizing (LSD / manual / auto-switch
  paths), ConfigPanel presets/toggle/sliders (95% WR / +392% claims
  were never computed from the canonical trigger). `nBars` now
  reports bars actually evaluated. Runner floor unified to entry
  ±0.10 (keeper parity; old RANGE 0.15 / other 0.05 split gone).

## 3. Files changed (all under `~/workspace/scanner-app-fixed`)

- **NEW** `priorityFees.cjs` (shared priority-fee config).
- **NEW** `tests/trigger.test.ts`, `tests/tier-parity.test.ts`
  (25 tests total; run with `npm test`).
- **NEW** `scripts/verify-trigger.ts` (real-klines verification;
  run with `npx tsx scripts/verify-trigger.ts`, `TRACE=1` for
  per-trade lines).
- **NEW** `render.yaml` (build `npm run build`, start
  `node server.cjs`; see the state-persistence warning inside).
- **NEW** `PHASE2_NOTES.md` (this file).
- **Rewritten:** `server_strategy_auto_switcher.cjs` (canonical
  tiers, deliberate-short gate, chop traded, fee guard, direction
  confirmation, return contract preserved), `README.md` (no Gemini
  references), `.env.example` (no Gemini/AI Studio blocks, fee vars
  documented, 1000 micro-lamports default).
- **Edited:** `bot-service.cjs` (direction allowlist incl. designed
  shorts, fee info forwarding, keeper short fixes, `/state` exposes
  real tp1/tp2, TDZ fix, position-cap source, regime recording fix,
  chop-aware stagnation), `public/jupiter.js` (shared fee config),
  `src/engine/trigger.ts` + `src/engine/tiers.ts` (prior-attempt
  files, reconciled not duplicated), `src/engine/indicators.ts`
  (`isBearishCandle`, calcSignalEngine removal note),
  `src/engine/backtest.ts` (canonical trigger, real 1h HTF, 5m proxy
  documented, direction-aware execution, canonical sizing),
  `src/types.ts` (legacy-field comments),
  `src/components/LiveDashboardView.tsx` (canonical trigger,
  UNKNOWN state, designed-short dispatch, postMessage bridge
  excised), `src/components/ConfigPanel.tsx` (canonical tier matrix,
  manual sizing removed), `src/components/TradeMonitoringCard.tsx`
  (baseMark fills, side-aware liquidation, copy sync),
  `src/components/AutoTradeJupiterView.tsx` (manual test signal,
  real TP/SL columns, copy sync), `src/components/NoteBanner.tsx`
  (generator wicks 1.5–5%, canonical TP values, no LSD/compounding),
  `src/components/Header.tsx` (tier name default),
  `src/components/TradesLedger.tsx` (no fabricated sides/timestamps),
  `src/components/DashboardCalculator.tsx` (Margin/Lev inputs, no
  fabricated side), `src/utils/exportCsv.ts` (LSD column → Side),
  `public/dashboard.html` (redirect stub), `server.cjs` + 
  `vite.config.ts` (`/dashboard` → `/`), `package.json` (dropped
  `@google/genai` + `motion`, added `engines: node >= 20` and the
  `test` script), `package-lock.json` (regenerated).
- **Deleted:** `public/jupiter.cjs` (zero references),
  `public/config.js` (only the retired page used it; carried a
  browser Telegram-token pattern and a devnet default).
- **Restored after testing:** `public/paper-positions.json` is back
  to the Phase 1 empty ledger (smoke tests wrote orders into it;
  they were removed afterward).

## 4. Test results

### Unit tests — 25/25 pass (`npm test`)

`tests/trigger.test.ts` (18): standard long, slow-bull long (RANGE
and CHOP), chop long at reduced size, chop short, bear short,
flash-crash sit-out (long and short), doji/no-hook, omitted
confirmation = 0 (never auto-confirmed), 1-bar confirmation
insufficient, feed failure → UNKNOWN, conflicting hooks → NONE,
VWMA null → NONE, BULL TP2 rule, penny-scale entry offsets, tier
margins T1/T2/T3. `tests/tier-parity.test.ts` (7): field-for-field
tier parity, leverage rules, risk caps, margins, chop constants,
tier-selection boundaries.

### Lint + build — clean

- `npm run lint` (`tsc --noEmit`): exit 0, no errors.
- `npm run build` (`vite build`): passes (one pre-existing chunk-size
  warning, >500 kB bundle — unchanged from before Phase 2).
- `node --check`: clean on `server.cjs`, `bot-service.cjs`,
  `server_strategy_auto_switcher.cjs`, `priorityFees.cjs`,
  `public/jupiter.js`.
- Phase 1 smoke scripts were not saved as files in the copy, so they
  could not be re-run verbatim; the paper-mode HTTP smoke below
  covers the same gates.

### Paper-mode HTTP smoke (server.cjs, PAPER_TRADING=true, token auth)

- POST `/signal` without auth → 401. ✓
- POST `/signal` green long (paper) → placed, mode `paper`,
  tp1 0.35 / tp2 0.55. ✓
- POST `/signal` red WITHOUT `designedShort` → 403
  `DIRECTION_NOT_ALLOWED`. ✓
- POST `/signal` red WITH `designedShort: true` → placed, side
  Short, SL 101.101 (dollar-cap-clamped), TP 100.45. ✓
- Keeper short, end to end: simulated fill at 101, price moved to
  100.50 (favorable) → `lowestPrice` tracked to 100.50 (favorable
  extreme, Phase 2 fix), TP1 hit at 100.65 banked 30% ($0.52),
  runner locked at +10¢ → stopLoss 101.101 → 100.90. ✓
- POST `/close` with no target → 400 (Phase 1 gate intact). ✓
- Note: a pending limit order is NOT keeper-managed until filled
  (correct — the first favorable-move probe showed no ratchet
  because the order was still pending; after the simulated fill the
  ratchet worked as above).

### Real-klines verification — `scripts/verify-trigger.ts` (REAL data)

Fetched 30 days of Binance SOLUSDT klines (15m: 2880 bars,
2026-09-26 → 2026-10-26; 5m: 8640 bars for REAL 2-bar confirmation;
1h aggregated for HTF). Three non-overlapping 48h windows, start
balance $250 (T3), fee 0.0008 × notional per fill, server boost rule
(+10x only on BULL/GRADE_A). Final run (after two harness fixes —
see below):

| Window | Signals (L/S) | Trades | Win rate | Avg win | Avg loss | Net | Max DD |
|---|---|---|---|---|---|---|---|
| Slow-bull, Oct 3–4 | 4 (4/0) | 4 | 0.0% | $0.00 | −$2.88 | −$11.53 | 4.61% |
| Chop, Oct 9–10 | 7 (2/5) | 7 | 0.0% | $0.00 | −$4.50 | −$31.51 | 12.60% |
| Bear, Oct 23–24 | 5 (2/3) | 5 | 20.0% | $0.24 | −$3.36 | −$13.18 | 5.37% |

UNKNOWN bars: 0 in all windows (real 5m feed was complete). Exit
mix: stagnation / chop-fast-exit / chandelier-at-breakeven dominate;
TP1 banks were rare. The bear window's prices ($100.75–$105.14)
independently match the user's observed SOL range that weekend.

**Read these numbers honestly, in both directions:**

- The trigger itself fires sensibly: direction mix matches each
  regime (all-long in slow-bull, mixed in chop, short-leaning in
  bear), 4–7 signals per 48h, no UNKNOWN on a complete feed. Losses
  came from exit economics, not from the trigger firing backwards.
- But expectancy on these three windows is NEGATIVE, and the reason
  is structural, not noise: at $100 margin × 50x, round-trip fees
  (0.0016 × notional at the script's 0.0008 rate) consume ~35–55% of
  the entire TP1 value ($0.35), and the typical banked outcome
  (early-bank at 70% of TP1 + runner floored at +$0.10) grosses
  ~$6–7 against ~$8–10 in fees. Stagnation (3-bar / 2-bar) and the
  1.2×ATR chandelier cut most runners at breakeven before they can
  pay for the losers, whose SL distances ($0.32–$0.60) are much
  larger than typical banked gains.
- **What this does NOT prove:** 16 trades across three cherry-picked
  48h windows is not a system verdict. The script omits Fisher-flip
  exits (present in `backtest.ts`), uses 15m-bar granularity (the
  live keeper reacts to ticks — faster exits, different fills), and
  uses the backtest's 0.0008 fee rate (see the calibration item in
  §2). Paper/simulate validation must come before any live sizing,
  and the fee-guard threshold (§2) does not protect these trades at
  current prices — it warns, it does not skip (at the server's
  0.0005 rate; at 0.0008, chop WOULD be skipped).
- **Harness fixes made during verification (documented, not hidden):**
  (1) first version measured stagnation adverse off the bar extreme
  (low/high) — a normal 15m bar routinely wicks 0.30×ATR against
  entry, so it killed nearly every trade at bar 3 (0% win rates via
  stagnation alone). Fixed to close-based adverse. (2) first version
  omitted the live keeper's early-bank rule; added (bank 30% at 70%
  of TP1, runner floored at entry ±0.10). (3) first version applied
  the +10x boost to every trade; fixed to the live rule (BULL or
  GRADE_A only). (4) first version exited 70% of tokens on unbanked
  trades; fixed to 100%.

## 5. Deliberately NOT changed

- `closeOrder`'s banked-PnL handling (P1 audit item, out of scope).
- `getDeduplicatedTradesList`'s hardcoded fallbacks (116.5625 /
  117.3125 / 25.00 / 500.00 — those fields are normally set at order
  creation).
- TradeMonitoringCard's impure `setTickDirection`-inside-updater, its
  guidance-close 404 path, and any hardcoded 1:1.43 ratio text.
- The DashboardCalculator backtest tab's empty state (kept as the
  "remove" choice, not rebuilt).
- The historical `AUDIT_REPORT.md` (the priority-fee unit correction
  lives here, not by editing the audit).
- `App.tsx` config defaults (leverage 50, compoundRate 0.5) — now
  ignored; `types.ts` documents them as legacy.
- TradeMonitoringCard's `/api/bot/signal` arm handler still sends
  `direction: 'sell'` without `designedShort`, so short arming now
  fails closed with `DIRECTION_NOT_ALLOWED` until guidance orders
  carry the canonical marker. Intentional, not a regression; long
  arming is unchanged.

## 6. Open decisions that still need the user

1. **Flash-crash shorts:** keep the both-directions sit-out, or allow
   the tight reduced-size breakdown short the task suggested? (Phase
   2 chose sit-out; see §2.)
2. **Fee-guard threshold:** keep 0.75/0.30, or tighten? At current
   SOL prices the guard warns on most trades but skips few — it is
   a warning system, not a profitability filter, at these levels.
3. **Dispatcher auto-shorts:** the Auto-Trader toggle now
   auto-forwards designed shorts under the same toggle that
   previously auto-traded only greens. Pausing the toggle keeps
   shorts manual. Confirm this is wanted.
4. **Fee-rate calibration:** resolve 0.0005 (server guard) vs 0.0008
   (backtest default) per side against the real Jupiter perps taker
   fee before live sizing — it flips whether chop trades pass the
   guard at current prices.
5. **Exit economics in light of §4:** stagnation windows, chandelier
   width, and TP1 distance were preserved from the user's design and
   NOT retuned on the basis of 16 trades. If paper/simulate shows
   the same fee-dominated pattern at scale, TP1 widening, a longer
   stagnation window, or a higher fee-guard threshold are the levers
   — each needs his call, not a silent retune.
6. **Render state persistence:** `render.yaml` ships WITHOUT a disk
   (see the warning inside): state files in the project root reset
   on redeploy. Persisting them needs a small code change (move
   state to a mounted data directory) — future work, not assumed.

## 7. What still is NOT verified

- **Any live broadcast.** Nothing here broadcasts a real transaction
  or proves live safety. Paper and simulate only. The first real
  broadcast is the user's tiny-live step, verified on Solscan.
- Full keeper parity between `scripts/verify-trigger.ts` and
  `backtest.ts` (Fisher-flip exits, tick granularity) — the script
  verifies the trigger, not the whole keeper.
- The 16-trade real-klines sample is directional evidence about exit
  economics, not a profitability verdict — a larger paper/simulate
  run is the next validation step, not a live one.
