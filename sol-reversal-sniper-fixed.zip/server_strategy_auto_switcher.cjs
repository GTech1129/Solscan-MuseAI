// server_strategy_auto_switcher.cjs
// ─────────────────────────────────────────────────────────────────────────
// Server-side strategy auto-switcher — the LAST gate before an order is
// placed. The React engine produces a proposed signal; this module
// validates it against server state and computes the canonical sizing.
//
// Phase 2 (canonical trigger unification): the TIERS table below is a
// field-for-field mirror of src/engine/tiers.ts (the single source of
// truth). tests/tier-parity.test.ts enforces the parity — if you edit
// one table, edit the other and run the test. Tier values (base
// leverage 20/35/50, +10x boost, 60x max reachable, 3%/5%/10% caps,
// $25/$50/$100 margins) are the user's numbers and are NOT changed by
// Phase 2. What changed vs the old server table (documented in
// src/engine/tiers.ts): T1 tp1Dist 0.18 -> 0.35, T1/T2 tp2Dist
// 0.32/0.65 -> 0.55/0.70, T1/T2 tp2AtrMult 0.55/0.85 -> 0.85/1.00,
// frontend slAtrMult 1.8/1.6 -> 1.2/1.5. The live T1 orders were already
// sized at 0.35 (the dispatcher payload always carried it); only the
// no-payload fallback path changes.
//
// Phase 2 signal rules implemented here:
//   * ADX < 20 is NO LONGER a hard sit-out (the old MARKET_CHOP sit-out
//     and the ADX < 12 ultra-low overlay are both REMOVED). A chop
//     regime trades at reduced size: half tier margin, TP1 0.20, TP2
//     at 75% of the tier distance, stops unchanged, faster keeper
//     exits (2-bar / 0.10-adverse stagnation — bot-service.cjs).
//   * FLASH_CRASH (ADX > 35 + HTF red + price below VWMA) remains a
//     LONG sit-out, and Phase 2 defines the short side too: NO new
//     shorts into a liquidation cascade (see PHASE2_NOTES.md for the
//     rationale and the flagged alternative).
//   * Deliberate SHORT path: a short payload is accepted ONLY when it
//     carries designedShort === true (the canonical engine's marker,
//     set by src/engine/trigger.ts when a mirror hook + 5m red
//     confirmation fired). Arbitrary red payloads are rejected.
//   * Bar confirmation: direction-appropriate count, defaulting to 0
//     when omitted — never auto-confirmed. Requires >= 2.
//   * Fee guard: expected round-trip cost (exchange fees + priority
//     fees from priorityFees.cjs) vs the TP1 distance value. Above
//     FEE_GUARD_MAX_FRACTION (default 0.75) the trade is SKIPPED;
//     above FEE_GUARD_WARN_FRACTION (default 0.30) it is placed with
//     a loud warning. Default ON, always computed. The 0.75 default
//     is deliberate: the fee ratio is margin-independent (exchange
//     fees scale with notional exactly like TP1 value), so at SOL
//     ~$100 the canonical chop trade sits at ~0.51 from exchange
//     fees alone (0.001 x entry / 0.20) — a 0.50 threshold would veto
//     the entire chop regime the user asked to trade. 0.75 still
//     blocks genuinely fee-dominated trades (chop at SOL > $150,
//     standard at SOL > $262.50, or any trade whose TP1 is small
//     against its price), and the 0.30 warning fires on every ~$100
//     chop trade, honestly flagging that fees are ~50% of TP1 there.
//   * Position cap (maxOpenPositions) is server execution policy, NOT
//     part of the canonical sizing table (tiers.ts is silent on it),
//     so it is preserved unchanged here (1/2/3 by tier) rather than
//     invented. bot-service.cjs enforces it.
// ─────────────────────────────────────────────────────────────────────────
const { getPriorityFeeConfig } = require('./priorityFees.cjs');

const TIERS = {
  TIER_1: {
    id: 'TIER_1',
    legacyId: 'TIER_1_MICRO',
    name: 'Peak Win Rate Mode (20x)',
    minBalance: 0,
    maxBalance: 99.9999,
    maxOpenPositions: 1,
    leverage: 20,
    riskCapPct: 0.03, // 3% equity risk (-$0.90 max loss on a $30 balance)
    maxRiskDollarCap: 3.00,
    tp1Dist: 0.35,
    tp2Dist: 0.55,
    tp2AtrMult: 0.85,
    slAtrMult: 1.2,
    defaultMargin: 25.00,
    compoundRate: 0.833,
    description: 'Capital preservation for micro-balances ($0-$100). Capped at 3% equity risk (-$0.90 max loss on $30 balance) with $25.00 margin collateral at 20x leverage ($500.00 position size). Maximum reachable leverage with the +10x boost is 30x.',
  },
  TIER_2: {
    id: 'TIER_2',
    legacyId: 'TIER_2_HYBRID',
    name: 'Hybrid Scaling Tier (35x)',
    minBalance: 100.00,
    maxBalance: 249.9999,
    maxOpenPositions: 2,
    leverage: 35,
    riskCapPct: 0.05, // 5% equity risk (-$5.00 max loss on $100 balance)
    maxRiskDollarCap: 12.50,
    tp1Dist: 0.35,
    tp2Dist: 0.70,
    tp2AtrMult: 1.0,
    slAtrMult: 1.5,
    defaultMargin: 50.00,
    compoundRate: 0.50,
    description: 'Balanced acceleration for intermediate balances ($100-$250). Capped at 5% equity risk (-$5.00 max loss on $100) with $50.00 margin collateral at 35x leverage ($1,750 total position). Maximum reachable leverage with the +10x boost is 45x.',
  },
  TIER_3: {
    id: 'TIER_3',
    legacyId: 'TIER_3_ALPHA',
    name: 'Max Alpha Mode (50x)',
    minBalance: 250.00,
    maxBalance: Infinity,
    maxOpenPositions: 3,
    leverage: 50,
    riskCapPct: 0.10, // 10% equity risk (-$25.00 max loss on $250 balance)
    maxRiskDollarCap: 50.00,
    tp1Dist: 0.35,
    tp2Dist: 0.85,
    tp2AtrMult: 1.2,
    slAtrMult: 1.5,
    defaultMargin: 100.00,
    compoundRate: 0.40,
    description: 'Maximum velocity compounding for accounts $250+. Capped at 10% equity risk (-$25.00 max loss on $250) with $100.00 collateral at 50x leverage ($5,000 total position). Maximum reachable leverage with the +10x boost is 60x.',
  },
};

const BOOST_LEVERAGE = 10; // +10x boost, unchanged: max reachable = 60x
const MAX_LEVERAGE = 60;

// Chop sizing (Phase 2): half tier margin, tighter TP1, TP2 at 75% of
// the tier distance. Stops are NOT tightened — a chop trade that stops
// tighter than the tier stop is just noise food; the exit speed comes
// from the tighter targets and the faster keeper stagnation exit.
const CHOP_MARGIN_MULTIPLIER = 0.5;
const CHOP_TP1_DIST = 0.20;
const CHOP_TP2_FACTOR = 0.75;

// Fee guard (Phase 2). Expected round-trip cost = 2 transactions'
// exchange fees (Jupiter perps taker ~0.05% of notional each way) +
// 2 transactions' priority fees (priorityFees.cjs, in SOL, converted
// at the entry price). Compared against tokens * tp1Dist (the dollar
// value of the first target distance). Default ON. With correct
// priority-fee units (see priorityFees.cjs), priority fees are
// negligible even at the cap, so the guard is effectively an
// exchange-fee-vs-TP1 sanity check — which is exactly what it
// should be: it blocks when the 0.1% round-trip exchange fee alone
// exceeds 75% of the first target's value.
function feeGuardConfig() {
  const max = parseFloat(process.env.FEE_GUARD_MAX_FRACTION || '0.75');
  const warn = parseFloat(process.env.FEE_GUARD_WARN_FRACTION || '0.30');
  return {
    maxFraction: Number.isFinite(max) && max > 0 ? max : 0.75,
    warnFraction: Number.isFinite(warn) && warn >= 0 ? warn : 0.30,
  };
}

// Internal Switcher State (circuit breaker; preserved from Phase 1).
const state = {
  enabled: true,
  currentBar: 0,
  tradeHistory: [],
  recentLossBars: [],
  consecutiveLosses: 0,
  standbyBarsRemaining: 0,
  circuitBreakerActive: false,
  lastTriggerReason: null,
};

function getPresetForBalance(balance) {
  const bal = Math.max(0, parseFloat(balance) || 0);
  if (bal < 100.00) return TIERS.TIER_1;
  if (bal < 250.00) return TIERS.TIER_2;
  return TIERS.TIER_3;
}

function getTierForBalance(balance) {
  return getPresetForBalance(balance);
}

// Risk-guardrail policy (P0 safety, Phase 1). Computes the ACTUAL
// reachable guardrails from the tier table instead of hardcoding them,
// so the live-arming gate cannot pass on a false premise. Shape is
// preserved: bot-service.cjs reads .passed and .detail.
function getRiskGuardrailPolicy() {
  const tiers = Object.values(TIERS);
  const maxBaseLeverage = Math.max(...tiers.map(t => t.leverage));
  const manualOffsetClamp = 60;
  const maxReachableLeverage = Math.min(manualOffsetClamp, maxBaseLeverage + BOOST_LEVERAGE);
  const slAtrMults = tiers.map(t => t.slAtrMult);
  const defaultMargins = tiers.map(t => t.defaultMargin);
  const riskCapPcts = tiers.map(t => t.riskCapPct);
  const checks = {
    maxLeverageCapped: Number.isFinite(maxReachableLeverage) && maxReachableLeverage <= 60,
    slCoefficientsBounded: slAtrMults.every(v => typeof v === 'number' && v >= 1.0 && v <= 2.0),
    marginsCapped: defaultMargins.every(v => typeof v === 'number' && v > 0 && v <= 500),
    riskCapsBounded: riskCapPcts.every(v => typeof v === 'number' && v > 0 && v <= 0.25),
  };
  const passed = Object.values(checks).every(Boolean);
  return {
    maxReachableLeverage,
    slAtrMults,
    defaultMargins,
    riskCapPcts,
    checks,
    passed,
    detail: `Max reachable leverage ${maxReachableLeverage}x (base ${maxBaseLeverage}x + ${BOOST_LEVERAGE}x boost, clamped at ${manualOffsetClamp}x) | SL coeffs ${slAtrMults.join('/')}x ATR | Tier margins $${defaultMargins.join('/$')} (code clamp $500) | Risk caps ${riskCapPcts.map(p => `${Math.round(p * 100)}%`).join('/')}`,
  };
}

function tickBar(barIndex) {
  if (typeof barIndex === 'number') {
    state.currentBar = barIndex;
  } else {
    state.currentBar += 1;
  }
  if (state.standbyBarsRemaining > 0) {
    state.standbyBarsRemaining -= 1;
    if (state.standbyBarsRemaining <= 0) {
      state.circuitBreakerActive = false;
      state.lastTriggerReason = 'Standby completed. Engine resumed.';
      console.log(`[CIRCUIT BREAKER] 5-bar Yellow Standby concluded. Engine resumed to Normal Active Mode.`);
    }
  }
}

// Canonical margin formula (mirrors src/engine/trigger.ts exactly):
// T1 min(balance, $25), T2 min(balance*0.50, $50), T3 min(balance*0.40,
// $100), $5 floor. Chop multiplies by 0.5 afterwards.
function canonicalMargin(preset, balance, marginMultiplier) {
  let m;
  if (preset.id === 'TIER_1') m = Math.min(balance, preset.defaultMargin);
  else if (preset.id === 'TIER_2') m = Math.min(balance * 0.50, preset.defaultMargin);
  else m = Math.min(balance * 0.40, preset.defaultMargin);
  m = Math.max(5.00, m) * marginMultiplier;
  return parseFloat(m.toFixed(2));
}

/**
 * Evaluates an incoming trade signal against the auto-switcher tier and
 * circuit breaker rules. Return contract (preserved from Phase 1 — 
 * bot-service.cjs consumes these fields):
 *   { execute, reason, preset, tier, leverage, margin, notional,
 *     positionSizeUsd, tokens, entryPrice, entryOffset, executionType,
 *     stopLoss, tp1, tp2, tp1Dist, tp2Dist, tp1Percent, tp2Percent,
 *     maxDollarLoss, effectiveSlDist, maxSlippageBps, candleMomentum,
 *     circuitBreaker, feeInfo, isChop, marginMultiplier, side,
 *     designedShort }
 */
function evaluateTradeSignal(currentSignal = {}, accountBalance = 240, barIndex) {
  if (typeof barIndex === 'number') {
    tickBar(barIndex);
  }

  const balance = Math.max(0, parseFloat(accountBalance) || 0);
  const preset = getPresetForBalance(balance);
  const noCircuit = { active: false, standbyBarsRemaining: 0, consecutiveLosses: state.consecutiveLosses };

  // 1. Circuit breaker (2-loss chop -> 5-bar sit-out; preserved).
  if (state.circuitBreakerActive && state.standbyBarsRemaining > 0) {
    return {
      execute: false,
      reason: `CIRCUIT_BREAKER_ACTIVE: 2 consecutive losses within 10 bars. In Yellow Standby Mode (${state.standbyBarsRemaining} bars remaining).`,
      preset,
      tier: preset.id,
      balance,
      circuitBreaker: {
        active: true,
        standbyBarsRemaining: state.standbyBarsRemaining,
        consecutiveLosses: state.consecutiveLosses,
      },
    };
  }

  // 2. Minimum account lockout ($10 Jupiter safety lockout; preserved).
  if (balance < 10.00) {
    return {
      execute: false,
      reason: `LOCKOUT_FLOOR_HIT: Account balance $${balance.toFixed(2)} is below the minimum $10.00 Jupiter safety lockout.`,
      preset,
      tier: preset.id,
      balance,
      circuitBreaker: noCircuit,
    };
  }

  // Direction + deliberate-short gate (Phase 2 SEAM, now implemented).
  // Long: green/buy/long. Short: red/sell/short ONLY with
  // designedShort === true (the canonical engine's marker). Anything
  // else — including yellow/standby and arbitrary red payloads — is
  // rejected here, before sizing.
  const rawDirection = String(currentSignal.direction || currentSignal.signal || 'green').toLowerCase();
  const isLongDir = ['green', 'buy', 'long'].includes(rawDirection);
  const isShortDir = ['red', 'sell', 'short'].includes(rawDirection);
  if (!isLongDir && !isShortDir) {
    return { execute: false, reason: 'DIRECTION_NOT_RECOGNIZED', preset, tier: preset.id, balance, circuitBreaker: noCircuit };
  }
  const designedShort = currentSignal.designedShort === true;
  if (isShortDir && !designedShort) {
    return { execute: false, reason: 'DIRECTION_NOT_ALLOWED', preset, tier: preset.id, balance, circuitBreaker: noCircuit };
  }
  const isLong = isLongDir;
  const side = isLong ? 'Long' : 'Short';

  const regimeRaw = String(currentSignal.regime || 'RANGE_BOUND_SUPPORT').toUpperCase();
  const isChop = regimeRaw === 'MARKET_CHOP' || regimeRaw === 'CHOP' || currentSignal.isChop === true;

  // FLASH_CRASH: no new positions in EITHER direction (Phase 2
  // decision — see PHASE2_NOTES.md "flash-crash short rule").
  if (regimeRaw === 'FLASH_CRASH' || regimeRaw === 'FLASH_CRASH_VOLATILITY' || regimeRaw === 'MARKET_FLASH_CRASH') {
    return { execute: false, reason: 'FLASH_CRASH_SITOUT', preset, tier: preset.id, balance, circuitBreaker: noCircuit };
  }

  // Yellow/standby signals are never trades (preserved).
  if (rawDirection === 'yellow' || rawDirection === 'standby') {
    return { execute: false, reason: `MARKET_CHOP_SITOUT: Signal is ${rawDirection}. 0x Leverage Sit-Out enforced.`, preset, tier: preset.id, balance, circuitBreaker: noCircuit };
  }

  // Bar confirmation (Phase 2 fix): direction-appropriate count,
  // defaulting to 0 when omitted — never auto-confirmed. Requires
  // >= 2 consecutive confirming 5m bars (green for longs, red for
  // shorts). Legacy field names are accepted as fallbacks so older
  // dashboard callers keep working; the canonical trigger sends
  // consecutiveGreen5m / consecutiveRed5m.
  const confirmCount = isLong
    ? (currentSignal.consecutiveGreen5m ?? currentSignal.greenBarCount ?? currentSignal.consecutiveGreen ?? currentSignal.barConfirmation ?? 0)
    : (currentSignal.consecutiveRed5m ?? currentSignal.redBarCount ?? currentSignal.consecutiveRed ?? currentSignal.barConfirmation ?? 0);
  const confirmedBars = Number(confirmCount);
  if (!Number.isFinite(confirmedBars) || confirmedBars < 2) {
    return {
      execute: false,
      reason: `WAITING_5M_BAR_CONFIRMATION: Requires 2-Bar Confirmation on 5m chart (currently ${Number.isFinite(confirmedBars) ? confirmedBars : 0}/2 bars).`,
      preset,
      tier: preset.id,
      balance,
      circuitBreaker: noCircuit,
    };
  }

  // Setup grade: default GRADE_B (the previous default of GRADE_A
  // overstated confidence for payloads that carried no grade).
  const setupGrade = String(currentSignal.setupGrade || 'GRADE_B').toUpperCase();

  // Leverage: tier base + 10x boost on BULL_TREND_DRIFT / GRADE_A
  // (preserved rule; the canonical trigger's BULL regime and GRADE_A
  // are what trigger the boost, so reachable max stays 60x).
  // The old manualLeverageOffset override is REMOVED in Phase 2: it
  // had no UI sender and was an unauthenticated leverage lever.
  let effectiveLeverage = preset.leverage;
  if (regimeRaw === 'BULL_TREND_DRIFT' || setupGrade === 'GRADE_A') {
    effectiveLeverage += BOOST_LEVERAGE;
  }
  effectiveLeverage = Math.min(MAX_LEVERAGE, effectiveLeverage);

  // Sizing. Chop trades at half tier margin with tighter targets;
  // everything else uses the full tier table. The payload may carry
  // the canonical engine's own marginMultiplier / tp1Dist / tp2Dist
  // (the React trigger computes them); when it does, the payload
  // values win (they ARE the canonical computation) — otherwise the
  // chop defaults below apply. BULL tp2 mirrors the trigger:
  // max(1.20, 1.50x ATR).
  const marginMultiplier = isChop
    ? (Number.isFinite(Number(currentSignal.marginMultiplier)) ? Number(currentSignal.marginMultiplier) : CHOP_MARGIN_MULTIPLIER)
    : 1;
  const margin = canonicalMargin(preset, balance, marginMultiplier);
  const curATR = parseFloat(currentSignal.atr) || 0.35;
  const tp1Dist = isChop
    ? (Number.isFinite(Number(currentSignal.tp1Dist ?? currentSignal.tp1)) ? Number(currentSignal.tp1Dist ?? currentSignal.tp1) : CHOP_TP1_DIST)
    : (Number.isFinite(Number(currentSignal.tp1Dist ?? currentSignal.tp1)) ? Number(currentSignal.tp1Dist ?? currentSignal.tp1) : preset.tp1Dist);
  let tp2Dist;
  if (Number.isFinite(Number(currentSignal.tp2Dist ?? currentSignal.tp2))) {
    tp2Dist = Number(currentSignal.tp2Dist ?? currentSignal.tp2);
  } else if (isChop) {
    // Rounded to cents, exactly like the canonical trigger
    // (Number((tier.tp2Dist * 0.75).toFixed(2)) = 0.41, not 0.4125).
    tp2Dist = parseFloat((preset.tp2Dist * CHOP_TP2_FACTOR).toFixed(2));
  } else if (regimeRaw === 'BULL_TREND_DRIFT') {
    tp2Dist = Math.max(1.20, parseFloat((curATR * 1.50).toFixed(2)));
  } else {
    tp2Dist = preset.tp2Dist;
  }
  const tp1Percent = currentSignal.tp1Percent !== undefined ? parseFloat(currentSignal.tp1Percent) : 30;
  const tp2Percent = currentSignal.tp2Percent !== undefined ? parseFloat(currentSignal.tp2Percent) : 70;

  // Risk cap: max(0.25, min(balance * riskCapPct, maxRiskDollarCap)).
  const equityRiskDollar = balance * preset.riskCapPct;
  const maxDollarLoss = Math.max(0.25, Math.min(equityRiskDollar, preset.maxRiskDollarCap));

  const notional = parseFloat((margin * effectiveLeverage).toFixed(2));

  // Entry offset (preserved rules; the canonical trigger sends its own
  // computed offset, which wins when present). Momentum = close
  // within 0.10% of the favorable extreme -> post-only best bid.
  // ATR < 0.35 -> 0.10x ATR clamped to 3-5c (penny scale); otherwise
  // 0.25x ATR clamped to 8-20c.
  const barClose = parseFloat(currentSignal.candleClose || currentSignal.close || currentSignal.price) || 0;
  const barHigh = parseFloat(currentSignal.candleHigh || currentSignal.high || currentSignal.price) || 0;
  const candleMomentum = currentSignal.candleMomentum !== undefined
    ? Boolean(currentSignal.candleMomentum)
    : (barHigh > 0 && barClose >= (barHigh - (0.0010 * barClose)));
  let entryOffset = 0.00;
  let executionType = 'POST_ONLY_BEST_BID';
  if (candleMomentum) {
    executionType = 'POST_ONLY_BEST_BID';
    entryOffset = 0.00;
  } else if (curATR < 0.35) {
    executionType = 'DYNAMIC_ATR_LIMIT';
    entryOffset = Math.max(0.03, Math.min(parseFloat((curATR * 0.10).toFixed(2)), 0.05));
  } else {
    executionType = 'DYNAMIC_ATR_LIMIT';
    entryOffset = Math.max(0.08, Math.min(parseFloat((curATR * 0.25).toFixed(2)), 0.20));
  }
  if (currentSignal.entryOffset !== undefined && !isNaN(parseFloat(currentSignal.entryOffset))) {
    entryOffset = parseFloat(currentSignal.entryOffset);
  }

  const price = parseFloat(currentSignal.price) || 140.0;
  const entryPrice = isLong ? price - entryOffset : price + entryOffset;
  const tokens = parseFloat((notional / entryPrice).toFixed(4));

  // Stop loss: ATR x tier coeff, clamped by the equity risk cap
  // (preserved safety: the stop distance may not lose more than
  // maxDollarLoss after fees). The backtest applies the same clamp
  // so live and backtest SL conversion agree.
  const slAtrDist = curATR * preset.slAtrMult;
  const fullFeeEst = notional * 0.0008; // 0.08% roundtrip fee estimate
  const maxLossPriceDist = tokens > 0 && maxDollarLoss > fullFeeEst
    ? (maxDollarLoss - fullFeeEst) / tokens
    : slAtrDist;
  const effectiveSlDist = Math.min(slAtrDist, maxLossPriceDist);
  const stopLoss = isLong ? entryPrice - effectiveSlDist : entryPrice + effectiveSlDist;
  const takeProfit1 = isLong ? entryPrice + tp1Dist : entryPrice - tp1Dist;
  const takeProfit2 = isLong ? entryPrice + tp2Dist : entryPrice - tp2Dist;

  // Fee guard (Phase 2): expected round-trip cost vs TP1 value.
  // Exchange: 0.05% of notional per side. Priority: shared config.
  const exchangeFeePerSide = 0.0005 * notional;
  const pf = getPriorityFeeConfig();
  const priorityFeeUsdPerTx = pf.solPerTx * entryPrice;
  const roundTripFeesUsd = 2 * exchangeFeePerSide + 2 * priorityFeeUsdPerTx;
  const tp1ValueUsd = tokens * tp1Dist;
  const feeRatio = tp1ValueUsd > 0 ? roundTripFeesUsd / tp1ValueUsd : Infinity;
  const fg = feeGuardConfig();
  const feeInfo = {
    roundTripFeesUsd: parseFloat(roundTripFeesUsd.toFixed(4)),
    tp1ValueUsd: parseFloat(tp1ValueUsd.toFixed(4)),
    feeRatio: parseFloat(feeRatio.toFixed(4)),
    maxFraction: fg.maxFraction,
    warnFraction: fg.warnFraction,
    feeWarning: feeRatio > fg.warnFraction,
  };
  if (feeRatio > fg.maxFraction) {
    return {
      execute: false,
      reason: 'FEE_GUARD_SKIP',
      preset,
      tier: preset.id,
      balance,
      circuitBreaker: noCircuit,
      feeInfo,
    };
  }

  return {
    execute: true,
    preset: {
      name: preset.name,
      tier: preset.id,
      description: preset.description,
      leverage: preset.leverage,
      riskCapPct: preset.riskCapPct,
      maxRiskDollarCap: preset.maxRiskDollarCap,
      maxOpenPositions: preset.maxOpenPositions,
    },
    tier: preset.id,
    side,
    designedShort,
    isChop,
    marginMultiplier,
    regime: regimeRaw,
    setupGrade,
    confirmedBars,
    baseLeverage: preset.leverage,
    leverage: effectiveLeverage,
    maxMarginUsd: 500,
    maxSlippageBps: 5,
    margin: parseFloat(margin.toFixed(2)),
    notional: parseFloat(notional.toFixed(2)),
    positionSizeUsd: parseFloat(notional.toFixed(2)),
    tokens,
    candleMomentum,
    executionType,
    entryOffset: parseFloat(entryOffset.toFixed(4)),
    entryPrice: parseFloat(entryPrice.toFixed(4)),
    stopLoss: parseFloat(stopLoss.toFixed(4)),
    tp1: parseFloat(takeProfit1.toFixed(4)),
    tp2: parseFloat(takeProfit2.toFixed(4)),
    tp1Dist: parseFloat(tp1Dist.toFixed(4)),
    tp2Dist: parseFloat(tp2Dist.toFixed(4)),
    tp1Percent,
    tp2Percent,
    maxDollarLoss: parseFloat(maxDollarLoss.toFixed(2)),
    effectiveSlDist: parseFloat(effectiveSlDist.toFixed(4)),
    feeInfo,
    circuitBreaker: {
      active: state.circuitBreakerActive,
      standbyBarsRemaining: state.standbyBarsRemaining,
      consecutiveLosses: state.consecutiveLosses,
    },
  };
}

/**
 * Called whenever a trade settles.
 * Evaluates consecutive losses to trigger the 2-Loss Chop Circuit Breaker.
 */
function onTradeSettled(netPnlUsd, details = {}) {
  const pnl = parseFloat(netPnlUsd) || 0;
  const exitBar = typeof details.exitBar === 'number' ? details.exitBar : state.currentBar;

  state.tradeHistory.push({
    pnl,
    exitBar,
    timestamp: Date.now(),
    reason: details.reason || (pnl >= 0 ? 'WIN' : 'LOSS'),
  });

  if (pnl < 0) {
    state.recentLossBars.push(exitBar);
    state.consecutiveLosses += 1;
    if (state.recentLossBars.length >= 2) {
      const len = state.recentLossBars.length;
      const lastLossBar = state.recentLossBars[len - 1];
      const prevLossBar = state.recentLossBars[len - 2];
      if (lastLossBar - prevLossBar <= 10 && state.consecutiveLosses >= 2) {
        state.circuitBreakerActive = true;
        state.standbyBarsRemaining = 5;
        state.lastTriggerReason = `2 consecutive stop losses within 10 bars (bars ${prevLossBar} & ${lastLossBar}). Engaged 5-bar Yellow Standby Mode.`;
        console.warn(`⚠️ [CIRCUIT BREAKER TRIGGERED] ${state.lastTriggerReason}`);
      }
    }
  } else {
    state.consecutiveLosses = 0;
  }

  return {
    circuitBreakerActive: state.circuitBreakerActive,
    standbyBarsRemaining: state.standbyBarsRemaining,
    consecutiveLosses: state.consecutiveLosses,
    lastTriggerReason: state.lastTriggerReason,
  };
}

function getAutoSwitcherState(balance = 240) {
  const activePreset = getPresetForBalance(balance);
  return {
    enabled: state.enabled,
    balance: parseFloat(balance),
    activeTier: activePreset.id,
    activePreset,
    tiers: TIERS,
    circuitBreaker: {
      active: state.circuitBreakerActive,
      standbyBarsRemaining: state.standbyBarsRemaining,
      consecutiveLosses: state.consecutiveLosses,
      lastTriggerReason: state.lastTriggerReason,
      recentLossCount: state.recentLossBars.length,
    },
    currentBar: state.currentBar,
    totalTradesLogged: state.tradeHistory.length,
  };
}

function resetCircuitBreaker() {
  state.circuitBreakerActive = false;
  state.standbyBarsRemaining = 0;
  state.consecutiveLosses = 0;
  state.recentLossBars = [];
  state.lastTriggerReason = 'Manually reset by user.';
  console.log('[CIRCUIT BREAKER] Reset by operator. Returning to Active Ready state.');
}

module.exports = {
  TIERS,
  BOOST_LEVERAGE,
  MAX_LEVERAGE,
  CHOP_MARGIN_MULTIPLIER,
  CHOP_TP1_DIST,
  CHOP_TP2_FACTOR,
  getPresetForBalance,
  getTierForBalance,
  evaluateTradeSignal,
  onTradeSettled,
  tickBar,
  getAutoSwitcherState,
  resetCircuitBreaker,
  getRiskGuardrailPolicy,
  feeGuardConfig,
};
