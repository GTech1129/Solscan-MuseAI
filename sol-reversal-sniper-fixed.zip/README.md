# SOL Reversal Sniper — backtest engine + Jupiter auto-trading bot + React dashboard

A SOL perpetuals reversal system: one canonical signal trigger, tiered
sizing, a keeper that manages TP/SL/trailing stops, and a backtest that
uses the exact same trigger as live trading. Target network is **mainnet**
(see "Rollout" below); devnet perps trading does not really work for this
program (the Jupiter perps program IDs in the code are mainnet addresses).

> **Safety first.** Nothing here broadcasts a real transaction unless
> you deliberately configure live mode, arm the safety toggle, and fund
> a wallet. The default configuration is paper. The first real broadcast
> is a tiny live trade verified on Solscan — never a first-run experiment.

## What it is (Phase 2 architecture)

- **One canonical trigger** — `src/engine/trigger.ts` (`evaluateTrigger`).
  The live dashboard (`src/components/LiveDashboardView.tsx`) and the
  backtest (`src/engine/backtest.ts`) call the same function, so they
  cannot print different answers on the same candles. Regime →
  hooks → 5m confirmation → sizing, in that order. The old standalone
  `dashboard.html` page (own signal, own cooldown, hardcoded $120
  margin) is retired to a redirect to `/`.
- **Long + designed-short paths.** Standard hook (CCI + Fisher + candle)
  and slow-bull/slow-bear hooks (Tenkan 2 bars + 15m volume ≥ 25k) in
  both directions, each confirmed by 2 consecutive 5m bars. A short is
  accepted by the server **only** when it carries the canonical engine's
  `designedShort` marker — never for an arbitrary red payload.
- **Chop is traded, not sat out.** ADX < 20 means half tier margin,
  TP1 0.20, TP2 at 75% of tier distance, and faster keeper exits
  (2-bar / $0.10-adverse stagnation instead of 3-bar / $0.15).
- **Flash crash sits out both directions.** ADX > 35 + 1H red + price
  below VWMA = no new positions, long or short (see PHASE2_NOTES.md for
  the rationale and the flagged alternative).
- **One tier table** — `src/engine/tiers.ts`, mirrored by
  `server_strategy_auto_switcher.cjs` (parity enforced by
  `tests/tier-parity.test.ts`): base leverage 20/35/50, +10x server
  boost (max 60x reachable), risk caps 3%/5%/10%, margins $25/$50/$100,
  TP1 0.35 (0.20 chop), TP2 0.55/0.70/0.85 (0.75× chop; BULL
  max(1.20, 1.50× ATR)), SL 1.2/1.5/1.5× ATR clamped by the tier risk cap.
- **Fee guard (server).** Expected round-trip fees vs TP1 value: skip
  above 75%, warn above 30% (env-tunable). Priority fees are env-driven
  (`PRIORITY_FEE_MICRO_LAMPORTS`, default 1000, capped at 50000 — see
  `priorityFees.cjs` for the unit math).
- **5m feed failure = UNKNOWN, loudly.** A failed 5m feed shows an
  explicit UNKNOWN state with a visible warning — never a silent block,
  never a stale green.

## Run locally

Prerequisites: Node.js ≥ 20.

```bash
npm install
cp .env.example .env   # then edit: start with PAPER_TRADING=true
npm run dev            # Vite dev server on :3000 (bot API mounted as middleware)
```

Production: `npm run build` then `npm start` (`node server.cjs`, serves
`dist/` + the bot API on the same origin).

## Trading-mode ladder (env-driven, never a code edit)

| Stage | Env | What happens |
|---|---|---|
| 1 — Paper (default) | `PAPER_TRADING=true` | Local virtual fills only. Never touches the chain. |
| 2 — Simulate | `PAPER_TRADING=false`, `SIMULATE_TX=true` | Builds the real transaction, simulates against the RPC, never broadcasts. |
| 3 — Live (tiny first) | Both `false` | Real broadcast on `SOLANA_NETWORK`. Additionally requires `BOT_AUTH_TOKEN` set, a configured wallet keypair, ≥ 0.02 SOL gas, and the safety toggle armed via `/safety-toggle`. Unarmed live signals are **rejected**, never silently papered. |

Rollout: paper → simulate → tiny live on mainnet (verify on Solscan) →
scale size only after tiny live verifies. Devnet + live flags forces
effective SIMULATE with a warning (there is no devnet perps deployment).

Required env vars: `SOLANA_NETWORK`, `PAPER_TRADING`, `SIMULATE_TX`,
`SOLANA_RPC`, `BOT_AUTH_TOKEN`, `WALLET_ENCRYPTION_KEY`,
`DASHBOARD_ORIGIN`. Optional: `PRIORITY_FEE_MICRO_LAMPORTS`,
`COMPUTE_UNIT_LIMIT`, `FEE_GUARD_MAX_FRACTION`,
`FEE_GUARD_WARN_FRACTION`. Full documentation in `.env.example`.

**Deploying?** Do not deploy to a public URL without `BOT_AUTH_TOKEN`
set and `NODE_ENV=production`. See `render.yaml` for a Render service
definition (build `npm run build`, start `node server.cjs`).

**State persistence note:** bot state lives in JSON files in the project
root (`paper-positions.json`, etc.). On Render without a persistent disk
these reset on redeploy. A disk cannot simply mount over the project
root (it would hide the code); persisting state across deploys needs a
small code change (move state storage to a mounted data directory) —
flagged as future work in PHASE2_NOTES.md, not silently assumed.

## Tests and verification

```bash
npm run lint        # tsc --noEmit
npm run build       # vite build
npm test            # tsx --test tests/*.test.ts
```

- `tests/trigger.test.ts` — unit tests for the canonical trigger
  (standard/slow-bull long, chop long/short at reduced size, bear
  short, flash-crash sit-out, doji/no-hook, confirmation missing,
  feed failure → UNKNOWN, conflicting hooks).
- `tests/tier-parity.test.ts` — asserts the TS tier table and the CJS
  server tier table agree field-for-field.
- `scripts/verify-trigger.ts` — backtests the canonical trigger on
  **real Binance klines** (15m/5m/1h via Binance Vision) across
  slow-bull, chop, and bear stretches, reporting per-regime signals,
  trades, win rate, avg win/loss, and max drawdown. Run with
  `npx tsx scripts/verify-trigger.ts`. Results are printed, never
  hardcoded; see PHASE2_NOTES.md for the latest run.

## What is NOT verified

Live broadcast is **not** verified by any test here — it cannot be
without real funds. The first real broadcast is the user's tiny-live
step, verified on Solscan. Do not claim live safety from paper/simulate
results.

## Phase records

- `PHASE1_FIXES.md` — P0 safety fixes (auth, mode gates, wallet
  unification, fake-data removal).
- `PHASE2_NOTES.md` — Phase 2 design decisions, what changed, test
  results, what was deliberately not changed, and open decisions.
